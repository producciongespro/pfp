<?php
function conectarDB(){

        $servidor = "localhost:3306";
        $usuario = "sistemap_gespro";
        $password = "Hola123Gespro";
        $bd = "sistemap_pfp";

    $conexion = mysqli_connect($servidor, $usuario, $password,$bd);

        if($conexion){
            echo "";
        }else{
            echo 'Ha sucedido un error inexperado en la conexion de la base de datos
';
        }

    return $conexion;
}
?>
