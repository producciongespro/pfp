<?
// Inspired by tutorials: http://www.phpfreaks.com/tutorials/130/6.php
// http://www.vbulletin.com/forum/archive/index.php/t-113143.html
// http://hudzilla.org

// Create the mysql backup file
// edit this section
$dbhost = "localhost"; // usually localhost
$dbuser = "recursos_gespro";
$dbpass = "Hola123Gespro";
$dbname = "recursos_bachi1";
$sendto = "Webmaster <usuariogespro@gmail.com>";
$sendfrom = "Respaldo automático <info@bachipruebas.com>";
$sendsubject = "Respaldo dario de la base de datos Bachitest1";
$bodyofemail = "Adjunto el respaldo diario";
// don't need to edit below this section

$backupfile = $dbname . date("Y-m-d") . '.sql';
system("mysqldump -h $dbhost -u $dbuser -p$dbpass $dbname > $backupfile");


// Mail the file


include('Mail.php');
include('Mail/mime.php');


$message = new Mail_mime();
$text = "$bodyofemail";
$message->setTXTBody($text);
$message->AddAttachment($backupfile);
$body = $message->get();
$extraheaders = array("From"=>"$sendfrom", "Subject"=>"$sendsubject");
$headers = $message->headers($extraheaders);
$mail = Mail::factory("mail");
$mail->send("$sendto", $headers, $body);


// Delete the file from your server
unlink($backupfile);
?>
